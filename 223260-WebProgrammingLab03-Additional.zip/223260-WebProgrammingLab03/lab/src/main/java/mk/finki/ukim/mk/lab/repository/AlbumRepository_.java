package mk.finki.ukim.mk.lab.repository;

import jakarta.annotation.PostConstruct;
import mk.finki.ukim.mk.lab.model.Album;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class AlbumRepository_ {

    private List<Album> albums = new ArrayList<>();

    @PostConstruct
    public void initializeData()
    {
        albums.add(new Album("Echoes of Eternity", "Progressive Rock", "2023"));
        albums.add(new Album("Neon Reverie", "Synthwave", "2021"));
        albums.add(new Album("Rust & Resonance", "Indie Folk","2022"));
        albums.add(new Album("Cosmic Rebirth", "Ambient Electronic","2020"));
        albums.add(new Album("Riot of Seasons", "Post-Punk Revival", "2024"));
    }

    public Optional<Album> save(Album album){
        albums.removeIf(a->a.getName().equals(album.getName()));
        albums.add(album);
        return Optional.of(album);
    }

    public List<Album> findAll(){
        return albums;
    }

    public void deleteById(Long id){
        albums.removeIf(i->i.getId().equals(id));
    }

    public Optional<Album> findById(Long id){
        return albums.stream().filter(i->i.getId().equals(id)).findFirst();
    }
}
