package mk.finki.ukim.mk.lab.repository;


import jakarta.annotation.PostConstruct;
import mk.finki.ukim.mk.lab.model.Album;
import mk.finki.ukim.mk.lab.model.Artist;
import mk.finki.ukim.mk.lab.model.Song;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class SongRepository {

    private List<Song> songs = new ArrayList<>();
    private final AlbumRepository albumRepository;

    public SongRepository(AlbumRepository albumRepository) {
        this.albumRepository = albumRepository;
    }
    @PostConstruct
    public void initializeData()
    {
        List<Album> albums = albumRepository.findAll();

        songs.add(new Song("1000", "Crimson Horizons", "Alternative Rock", 2022, albums.get(0)));
        songs.add(new Song("2000", "Electric Serenity", "Chillwave", 2023, albums.get(1)));
        songs.add(new Song("3000", "Midnight Tangents", "Jazz Fusion", 2021, albums.get(2)));
        songs.add(new Song("4000", "Fragments of Tomorrow", "Experimental Pop", 2024, albums.get(3)));
        songs.add(new Song("5000", "Echoed Reveries", "Dream Pop", 2020, albums.get(4)));
    }

    public Optional<Song> save(Song song) {
        songs.removeIf(s -> s.getTitle().equals(song.getTitle()));
        songs.add(song);
        return Optional.of(song);
    }

    public List<Song> findAll(){
        return songs;
    }
    public Optional<Song> findById(Long id) {
        if (id == null) {
            return Optional.empty();
        }
        return songs.stream()
                .filter(song -> id.equals(song.getId()))
                .findFirst();
    }

    public Optional<Song> findByTrackId(String trackId){
        return songs.stream()
                .filter(i -> trackId != null && trackId.equals(i.getTrackId()))
                .findFirst();

    }

    public Artist addArtistToSong(Artist artist, Song song){
        if (!song.getPerformers().contains(artist)){
            song.getPerformers().add(artist);
            save(song);
        }

        return artist;
    }

    public List<Song> search(String text){
        return songs.stream()
                .filter(s->s.getTitle().contains(text)||
                        s.getGenre().contains(text))
                .toList();
    }

    public void deleteById(Long id){
        songs.removeIf(i->i.getId().equals(id));
    }
}
