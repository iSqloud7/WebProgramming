package mk.finki.ukim.mk.lab.service;

import mk.finki.ukim.mk.lab.model.Artist;
import mk.finki.ukim.mk.lab.model.Song;

import java.util.List;
import java.util.Optional;

public interface SongService {
    List<Song> listSongs();

    Optional<Song> findById(Long id);

    Artist addArtistToSong(Artist artist, Song song);

    Optional<Song> save(String trackId, String title, String genre, Integer releaseYear, Long albumId);

    Optional<Song> update(Long id, String trackId, String title, String genre, Integer releaseYear, Long albumId);

    Optional<Song> findByTrackId(String trackId);

    void deleteById(Long id);
}
