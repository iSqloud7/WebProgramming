package mk.finki.ukim.mk.lab.repository;

import jakarta.annotation.PostConstruct;
import mk.finki.ukim.mk.lab.model.Artist;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class ArtistRepository {

    private List<Artist> artists = new ArrayList<>();

    @PostConstruct
    public void initializeData()
    {
        artists.add(new Artist("Elias ", "Vega", "A virtuoso guitarist and lyricist from Barcelona, Elias blends intricate melodies with introspective lyrics, leading the progressive rock scene with his band’s debut, Echoes of Eternity."));
        artists.add(new Artist("Luna ", "Hayes", "Hailing from Portland, Luna is a rising star in the synthwave genre, known for her vibrant beats and retro-futuristic aesthetics showcased in her acclaimed album Neon Reverie."));
        artists.add(new Artist("Oliver", "Finch", "A reclusive indie folk artist from Vermont, Oliver writes hauntingly beautiful tracks inspired by nature and solitude, with his breakout album Rust & Resonance earning widespread critical acclaim."));
        artists.add(new Artist("Astrid ", "Novak", "A Swedish producer and composer, Astrid is renowned for crafting ethereal soundscapes in the ambient electronic genre, with her latest work Cosmic Rebirth exploring themes of space and renewal."));
        artists.add(new Artist("Kai", "Dawson", " post-punk revivalist from Manchester, Kai infuses raw energy and poetic depth into his music, making waves with his explosive album Riot of Seasons."));

    }

    public Optional<Artist> save(Artist artist){
        artists.removeIf(c->c.getFirstName().equals(artist.getFirstName()));
        artists.add(artist);
        return Optional.of(artist);
    }

    public List<Artist> findAll(){
        return artists;
    }

    public Optional<Artist> findByName(String name){
        return artists.stream()
                .filter(a->a.getFirstName().equals(name))
                .findFirst();
    }
    public Optional<Artist> findById(Long id){
        return artists.stream()
                .filter(i->i.getId().equals(id))
                .findFirst();
    }

    public void deleteById(Long id){
        artists.removeIf(i->i.getId().equals(id));
    }
}
